import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell } from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Video, Mic, MicOff, VideoOff, PhoneOff, Send, Upload } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/consult")({
  head: () => ({ meta: [{ title: "Online Consultation — Ayurvedic Plus Clinic" }] }),
  component: ConsultPage,
});

function ConsultPage() {
  const [mic, setMic] = useState(true);
  const [cam, setCam] = useState(true);
  const [chat, setChat] = useState([
    { from: "doctor", text: "Hi Arjun, ready when you are." },
    { from: "me", text: "Yes doctor, joining now." },
  ]);
  const [msg, setMsg] = useState("");

  return (
    <AppShell>
      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">Online consultation</p>
        <h1 className="mt-2 font-display text-3xl font-semibold">Live with Dr. Ananya Sharma</h1>

        <div className="mt-6 grid gap-6 lg:grid-cols-[1.6fr_1fr]">
          <Card><CardContent className="p-0">
            <div className="relative aspect-video w-full overflow-hidden rounded-t-xl bg-gradient-to-br from-primary/30 via-primary/15 to-[oklch(0.78_0.13_82/0.25)]">
              <div className="absolute inset-0 grid place-items-center">
                <div className="text-center">
                  <div className="mx-auto grid h-24 w-24 place-items-center rounded-full bg-card/80 font-display text-2xl font-semibold text-primary shadow-lg">AS</div>
                  <p className="mt-3 font-semibold">Dr. Ananya Sharma</p>
                  <p className="text-xs text-foreground/70">HD video · stable connection</p>
                </div>
              </div>
              <div className="absolute bottom-4 right-4 grid h-28 w-44 place-items-center rounded-xl border border-border bg-card/90 shadow">
                <p className="text-xs text-muted-foreground">You</p>
              </div>
            </div>
            <div className="flex items-center justify-center gap-3 border-t border-border p-4">
              <Button size="icon" variant={mic ? "secondary" : "destructive"} className="rounded-full" onClick={() => setMic(!mic)}>{mic ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}</Button>
              <Button size="icon" variant={cam ? "secondary" : "destructive"} className="rounded-full" onClick={() => setCam(!cam)}>{cam ? <Video className="h-4 w-4" /> : <VideoOff className="h-4 w-4" />}</Button>
              <Button size="icon" variant="destructive" className="rounded-full" onClick={() => toast("Call ended")}><PhoneOff className="h-4 w-4" /></Button>
            </div>
          </CardContent></Card>

          <div className="space-y-4">
            <Card><CardContent className="p-5">
              <h3 className="font-display font-semibold">Chat</h3>
              <div className="mt-3 h-72 space-y-2 overflow-y-auto rounded-lg bg-muted/40 p-3">
                {chat.map((c, i) => (
                  <div key={i} className={`flex ${c.from === "me" ? "justify-end" : "justify-start"}`}>
                    <div className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm ${c.from === "me" ? "bg-primary text-primary-foreground" : "bg-card"}`}>{c.text}</div>
                  </div>
                ))}
              </div>
              <form
                className="mt-3 flex gap-2"
                onSubmit={(e) => { e.preventDefault(); if (!msg) return; setChat([...chat, { from: "me", text: msg }]); setMsg(""); }}
              >
                <Input value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Type a message…" />
                <Button size="icon" type="submit"><Send className="h-4 w-4" /></Button>
              </form>
            </CardContent></Card>

            <Card><CardContent className="p-5">
              <h3 className="font-display font-semibold">Share a report</h3>
              <p className="text-sm text-muted-foreground">PDF / image up to 10 MB</p>
              <Button variant="outline" className="mt-3 w-full rounded-full" onClick={() => toast.success("Report uploaded")}><Upload className="mr-1 h-4 w-4" />Upload report</Button>
            </CardContent></Card>
          </div>
        </div>
      </section>
    </AppShell>
  );
}
