import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CalendarCheck, ShieldCheck, Sparkles, Leaf, Heart, Activity, Brain, Quote, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AppShell } from "@/components/app-shell";
import { treatments, doctors } from "@/lib/mock-data";
import hero from "@/assets/hero-ayurveda.jpg";
import leaves from "@/assets/treatment-leaves.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Ayurvedic Plus Clinic — Holistic Healing Through Ayurveda" },
      { name: "description", content: "Personalized Ayurvedic treatments, consultations, and wellness programs by experienced doctors." },
      { property: "og:title", content: "Ayurvedic Plus Clinic" },
      { property: "og:description", content: "Holistic healing through Ayurveda. Book your consultation today." },
    ],
  }),
  component: Home,
});

const treatmentIcons = [Leaf, Activity, Sparkles, Heart, Brain, ShieldCheck];

function Home() {
  return (
    <AppShell>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute -left-32 top-10 h-72 w-72 rounded-full bg-primary/10 blur-3xl" />
          <div className="absolute right-0 top-40 h-80 w-80 rounded-full bg-[oklch(0.78_0.13_82/0.18)] blur-3xl" />
        </div>
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-16 sm:px-6 md:py-24 lg:grid-cols-[1.05fr_1fr]">
          <div className="animate-fade-up">
            <Badge variant="secondary" className="rounded-full border border-border bg-card/60 px-3 py-1 text-xs font-medium text-foreground/70">
              <span className="mr-2 inline-block h-1.5 w-1.5 rounded-full bg-primary" />
              Trusted by 12,000+ patients across India
            </Badge>
            <h1 className="mt-5 font-display text-4xl font-semibold leading-[1.05] tracking-tight text-balance sm:text-5xl md:text-6xl">
              Holistic Healing<br />
              Through <span className="italic text-primary">Ayurveda</span>
            </h1>
            <p className="mt-5 max-w-xl text-balance text-base text-muted-foreground sm:text-lg">
              Personalized Ayurvedic treatments, consultations, and wellness programs — designed around your prakriti, lifestyle, and goals.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Button asChild size="lg" className="rounded-full px-6">
                <Link to="/booking">
                  Book Appointment <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="rounded-full px-6">
                <Link to="/treatments">Explore treatments</Link>
              </Button>
            </div>
            <dl className="mt-10 grid max-w-md grid-cols-3 gap-6">
              {[
                { k: "14+", v: "Years experience" },
                { k: "40+", v: "Therapies" },
                { k: "4.9", v: "Avg. rating" },
              ].map((s) => (
                <div key={s.v}>
                  <dt className="font-display text-2xl font-semibold text-primary">{s.k}</dt>
                  <dd className="text-xs text-muted-foreground">{s.v}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="relative">
            <div className="absolute -inset-4 -z-10 rounded-[2rem] bg-gradient-to-br from-primary/10 via-transparent to-[oklch(0.78_0.13_82/0.15)] blur-2xl" />
            <div className="overflow-hidden rounded-[2rem] border border-border/60 shadow-xl">
              <img src={hero} alt="Ayurvedic herbs and copper vessels in a treatment room" width={1600} height={1200} className="h-full w-full object-cover" />
            </div>
            <div className="absolute -bottom-6 -left-6 hidden w-56 rounded-2xl border border-border bg-card p-4 shadow-lg sm:block">
              <div className="flex items-center gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary">
                  <CalendarCheck className="h-5 w-5" />
                </span>
                <div>
                  <p className="text-xs text-muted-foreground">Next available</p>
                  <p className="text-sm font-semibold">Today · 4:30 PM</p>
                </div>
              </div>
            </div>
            <div className="absolute -right-4 top-8 hidden rounded-2xl border border-border bg-card px-4 py-3 shadow-lg sm:flex items-center gap-2">
              <Star className="h-4 w-4 fill-gold text-gold" />
              <span className="text-sm font-semibold">4.9</span>
              <span className="text-xs text-muted-foreground">2,341 reviews</span>
            </div>
          </div>
        </div>
      </section>

      {/* Treatments */}
      <section className="border-t border-border/60 bg-secondary/30 py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
            <div className="max-w-2xl">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">Treatments</p>
              <h2 className="mt-2 font-display text-3xl font-semibold sm:text-4xl">Care designed for your dosha</h2>
              <p className="mt-3 text-muted-foreground">From deep Panchakarma cleanses to lifestyle resets — every protocol is matched to you.</p>
            </div>
            <Button asChild variant="ghost" className="rounded-full">
              <Link to="/treatments">View all <ArrowRight className="ml-1 h-4 w-4" /></Link>
            </Button>
          </div>

          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {treatments.map((t, i) => {
              const Icon = treatmentIcons[i % treatmentIcons.length];
              return (
                <Link to="/treatments" key={t.id} className="group surface-card hover-lift block p-6">
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary">
                    <Icon className="h-5 w-5" />
                  </span>
                  <h3 className="mt-4 font-display text-xl font-semibold">{t.name}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{t.tagline}</p>
                  <p className="mt-4 line-clamp-2 text-sm text-foreground/70">{t.description}</p>
                  <div className="mt-5 flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">{t.duration}</span>
                    <span className="font-semibold text-primary">from ${t.price}</span>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Doctors */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="grid items-center gap-10 lg:grid-cols-[1fr_1.2fr]">
            <div>
              <img src={leaves} alt="Fresh ayurvedic leaves on marble" width={800} height={800} loading="lazy" className="aspect-square w-full rounded-[2rem] border border-border/60 object-cover" />
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">Practitioners</p>
              <h2 className="mt-2 font-display text-3xl font-semibold sm:text-4xl">Meet our doctors</h2>
              <p className="mt-3 max-w-lg text-muted-foreground">A team of BAMS and MD-Ayurveda specialists, with combined experience of 80+ years.</p>

              <div className="mt-8 grid gap-4 sm:grid-cols-2">
                {doctors.map((d) => (
                  <div key={d.id} className="surface-card p-5">
                    <div className="flex items-center gap-3">
                      <div className="grid h-11 w-11 place-items-center rounded-full bg-primary/10 font-semibold text-primary">{d.avatar}</div>
                      <div>
                        <p className="text-sm font-semibold">{d.name}</p>
                        <p className="text-xs text-muted-foreground">{d.specialty}</p>
                      </div>
                    </div>
                    <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
                      <span>{d.experience} yrs experience</span>
                      <span className="flex items-center gap-1"><Star className="h-3 w-3 fill-gold text-gold" /> {d.rating}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial / CTA */}
      <section className="border-t border-border/60 bg-primary text-primary-foreground">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 md:py-20">
          <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr] lg:items-center">
            <div>
              <Quote className="h-8 w-8 text-gold" />
              <p className="mt-4 font-display text-2xl leading-snug sm:text-3xl">
                "Three weeks of Shirodhara and a small diet change gave me my sleep back. The team listens — they don't just prescribe."
              </p>
              <p className="mt-4 text-sm text-primary-foreground/70">— Anita R., Bengaluru · Stress Management program</p>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row lg:flex-col">
              <Button asChild size="lg" variant="secondary" className="rounded-full">
                <Link to="/booking">Book your consultation</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="rounded-full border-primary-foreground/30 bg-transparent text-primary-foreground hover:bg-primary-foreground/10">
                <Link to="/consult">Try an online session</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </AppShell>
  );
}
