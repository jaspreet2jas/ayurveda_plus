import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { doctors, treatments } from "@/lib/mock-data";
import { format } from "date-fns";
import { Check, MapPin, Video, CalendarCheck2 } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/booking")({
  head: () => ({ meta: [{ title: "Book Appointment — Ayurvedic Plus Clinic" }] }),
  component: Booking,
});

const slots = ["09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30"];

function Booking() {
  const [doctorId, setDoctorId] = useState(doctors[0].id);
  const [treatmentId, setTreatmentId] = useState(treatments[0].id);
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [time, setTime] = useState<string>("10:00");
  const [mode, setMode] = useState<"in-clinic" | "online">("in-clinic");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [confirmed, setConfirmed] = useState(false);

  const doctor = useMemo(() => doctors.find((d) => d.id === doctorId)!, [doctorId]);
  const treatment = useMemo(() => treatments.find((t) => t.id === treatmentId)!, [treatmentId]);

  const handleConfirm = () => {
    if (!name || !phone) {
      toast.error("Please enter your name and phone number");
      return;
    }
    setConfirmed(true);
    toast.success("Appointment confirmed", { description: "We'll send WhatsApp & SMS reminders." });
  };

  if (confirmed) {
    return (
      <AppShell>
        <section className="mx-auto max-w-2xl px-4 py-20 sm:px-6">
          <div className="surface-card p-10 text-center">
            <span className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-primary/10 text-primary">
              <CalendarCheck2 className="h-7 w-7" />
            </span>
            <h1 className="mt-5 font-display text-3xl font-semibold">You're booked!</h1>
            <p className="mt-2 text-muted-foreground">Confirmation #ASH-{Math.floor(100000 + Math.random() * 900000)}</p>

            <div className="mt-8 grid gap-4 text-left">
              {[
                ["Doctor", doctor.name],
                ["Treatment", treatment.name],
                ["Date", date ? format(date, "EEEE, dd MMM yyyy") : "—"],
                ["Time", time],
                ["Mode", mode === "online" ? "Online consultation" : "In-clinic visit"],
                ["Patient", name],
              ].map(([k, v]) => (
                <div key={k} className="flex items-center justify-between border-b border-border/60 pb-2 text-sm">
                  <span className="text-muted-foreground">{k}</span>
                  <span className="font-medium">{v}</span>
                </div>
              ))}
            </div>

            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Button onClick={() => setConfirmed(false)} variant="outline" className="rounded-full">Book another</Button>
              <Button className="rounded-full" onClick={() => toast("Reminder set", { description: "We'll WhatsApp you 1 day before." })}>Add to reminders</Button>
            </div>
          </div>
        </section>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <section className="mx-auto max-w-6xl px-4 py-12 sm:px-6 md:py-16">
        <div className="mb-8">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">Book</p>
          <h1 className="mt-2 font-display text-4xl font-semibold">Book your appointment</h1>
          <p className="mt-2 text-muted-foreground">Four short steps, less than a minute.</p>
        </div>

        <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <h2 className="font-display text-lg font-semibold">1. Choose your doctor</h2>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  {doctors.map((d) => (
                    <button
                      key={d.id}
                      onClick={() => setDoctorId(d.id)}
                      className={cn(
                        "flex items-center gap-3 rounded-xl border p-3 text-left transition-colors",
                        doctorId === d.id ? "border-primary bg-primary/5" : "border-border hover:bg-muted"
                      )}
                    >
                      <div className="grid h-10 w-10 place-items-center rounded-full bg-primary/10 text-sm font-semibold text-primary">{d.avatar}</div>
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold">{d.name}</p>
                        <p className="truncate text-xs text-muted-foreground">{d.specialty}</p>
                      </div>
                      {doctorId === d.id && <Check className="ml-auto h-4 w-4 shrink-0 text-primary" />}
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h2 className="font-display text-lg font-semibold">2. Select treatment</h2>
                <div className="mt-4 flex flex-wrap gap-2">
                  {treatments.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setTreatmentId(t.id)}
                      className={cn(
                        "rounded-full border px-4 py-1.5 text-sm transition-colors",
                        treatmentId === t.id ? "border-primary bg-primary text-primary-foreground" : "border-border hover:bg-muted"
                      )}
                    >
                      {t.name}
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h2 className="font-display text-lg font-semibold">3. Pick a date & time</h2>
                <div className="mt-4 grid gap-6 md:grid-cols-[auto_1fr]">
                  <Calendar mode="single" selected={date} onSelect={setDate} className="rounded-xl border bg-background p-3 pointer-events-auto" />
                  <div>
                    <Tabs value={mode} onValueChange={(v) => setMode(v as "in-clinic" | "online")}>
                      <TabsList>
                        <TabsTrigger value="in-clinic"><MapPin className="mr-1 h-3.5 w-3.5" />In-clinic</TabsTrigger>
                        <TabsTrigger value="online"><Video className="mr-1 h-3.5 w-3.5" />Online</TabsTrigger>
                      </TabsList>
                    </Tabs>
                    <p className="mt-4 text-xs font-medium uppercase tracking-wider text-muted-foreground">Available slots</p>
                    <div className="mt-2 grid grid-cols-3 gap-2 sm:grid-cols-4">
                      {slots.map((s) => (
                        <button
                          key={s}
                          onClick={() => setTime(s)}
                          className={cn(
                            "rounded-lg border px-2.5 py-2 text-sm transition-colors",
                            time === s ? "border-primary bg-primary text-primary-foreground" : "border-border hover:bg-muted"
                          )}
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h2 className="font-display text-lg font-semibold">4. Your details</h2>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <div className="grid gap-2">
                    <Label htmlFor="name">Full name</Label>
                    <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Riya Sharma" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="phone">Phone (WhatsApp)</Label>
                    <Input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+91 ..." />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Summary</h3>
                <div className="mt-4 space-y-3 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Doctor</span><span className="font-medium">{doctor.name}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Treatment</span><span className="font-medium">{treatment.name}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Date</span><span className="font-medium">{date ? format(date, "dd MMM yyyy") : "—"}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Time</span><span className="font-medium">{time}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Mode</span><Badge variant="secondary" className="rounded-full">{mode}</Badge></div>
                </div>
                <div className="my-5 h-px bg-border" />
                <div className="flex items-baseline justify-between">
                  <span className="text-sm text-muted-foreground">Consultation fee</span>
                  <span className="font-display text-2xl font-semibold text-primary">${treatment.price}</span>
                </div>
                <Button onClick={handleConfirm} size="lg" className="mt-5 w-full rounded-full">Confirm appointment</Button>
                <p className="mt-3 text-center text-xs text-muted-foreground">Free cancellation up to 6 hours before.</p>
              </CardContent>
            </Card>
          </aside>
        </div>
      </section>
    </AppShell>
  );
}
