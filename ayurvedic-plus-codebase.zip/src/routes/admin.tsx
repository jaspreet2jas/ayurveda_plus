import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { doctors, patients, appointments, revenueData, treatmentDistribution } from "@/lib/mock-data";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis, Legend } from "recharts";
import { Bell, TrendingUp, Users, Stethoscope, CalendarCheck, Download } from "lucide-react";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin Dashboard — Ayurvedic Plus Clinic" }] }),
  component: AdminDashboard,
});

const colors = ["var(--primary)", "var(--gold)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];

function AdminDashboard() {
  const stats = [
    { l: "Revenue (Jun)", v: "$31.9k", d: "+15.6%", icon: TrendingUp },
    { l: "Active patients", v: "238", d: "+27 this month", icon: Users },
    { l: "Practitioners", v: "12", d: "4 specialties", icon: Stethoscope },
    { l: "Appointments", v: "164", d: "this week", icon: CalendarCheck },
  ];

  return (
    <AppShell>
      <section className="border-b border-border/60 bg-secondary/30">
        <div className="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-4 py-8 sm:px-6">
          <div className="min-w-0">
            <p className="text-xs uppercase tracking-wider text-muted-foreground">Admin</p>
            <h1 className="truncate font-display text-2xl font-semibold sm:text-3xl">Clinic overview</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" className="shrink-0 rounded-full" asChild>
              <a href="/api/public/download-codebase" download>
                <Download className="mr-1 h-4 w-4" />
                Download ZIP for GitHub
              </a>
            </Button>
            <Button variant="outline" className="shrink-0 rounded-full"><Bell className="mr-1 h-4 w-4" />Notifications · 5</Button>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl space-y-6 px-4 py-10 sm:px-6">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((s) => (
            <Card key={s.l}><CardContent className="p-5">
              <div className="flex items-start justify-between">
                <p className="text-xs uppercase tracking-wider text-muted-foreground">{s.l}</p>
                <span className="grid h-8 w-8 place-items-center rounded-lg bg-primary/10 text-primary"><s.icon className="h-4 w-4" /></span>
              </div>
              <p className="mt-3 font-display text-3xl font-semibold">{s.v}</p>
              <p className="text-xs text-muted-foreground">{s.d}</p>
            </CardContent></Card>
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
          <Card><CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div><h3 className="font-display text-lg font-semibold">Revenue & patients</h3><p className="text-sm text-muted-foreground">Last 6 months</p></div>
            </div>
            <div className="mt-4 h-72">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={revenueData}>
                  <defs>
                    <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={12} />
                  <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                  <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12 }} />
                  <Area type="monotone" dataKey="revenue" stroke="var(--primary)" fill="url(#rev)" strokeWidth={2.5} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent></Card>

          <Card><CardContent className="p-6">
            <h3 className="font-display text-lg font-semibold">Treatment mix</h3>
            <p className="text-sm text-muted-foreground">Distribution this month</p>
            <div className="mt-4 h-72">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={treatmentDistribution} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={3}>
                    {treatmentDistribution.map((_, i) => <Cell key={i} fill={colors[i % colors.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12 }} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent></Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card><CardContent className="p-6">
            <h3 className="font-display text-lg font-semibold">Doctors</h3>
            <div className="mt-4 divide-y divide-border">
              {doctors.map((d) => (
                <div key={d.id} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 py-3">
                  <div className="flex min-w-0 items-center gap-3">
                    <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-primary/10 text-sm font-semibold text-primary">{d.avatar}</div>
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold">{d.name}</p>
                      <p className="truncate text-xs text-muted-foreground">{d.specialty} · {d.experience} yrs</p>
                    </div>
                  </div>
                  <Badge variant="secondary" className="shrink-0 rounded-full">★ {d.rating}</Badge>
                </div>
              ))}
            </div>
          </CardContent></Card>

          <Card><CardContent className="p-6">
            <h3 className="font-display text-lg font-semibold">Recent patients</h3>
            <div className="mt-4 divide-y divide-border">
              {patients.slice(0, 5).map((p) => (
                <div key={p.id} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold">{p.name}</p>
                    <p className="truncate text-xs text-muted-foreground">{p.prakriti} · {p.conditions.join(", ")}</p>
                  </div>
                  <span className="shrink-0 text-xs text-muted-foreground">{p.lastVisit}</span>
                </div>
              ))}
            </div>
          </CardContent></Card>
        </div>

        <Card><CardContent className="p-6">
          <h3 className="font-display text-lg font-semibold">Daily appointment volume</h3>
          <div className="mt-4 h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={[
                { d: "Mon", v: 18 }, { d: "Tue", v: 24 }, { d: "Wed", v: 21 }, { d: "Thu", v: 28 }, { d: "Fri", v: 32 }, { d: "Sat", v: 26 }, { d: "Sun", v: 15 },
              ]}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="d" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12 }} />
                <Bar dataKey="v" fill="var(--primary)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent></Card>
      </section>
    </AppShell>
  );
}
