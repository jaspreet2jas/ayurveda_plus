import { createFileRoute } from "@tanstack/react-router";
import { spawn } from "child_process";
import { Readable } from "stream";

export const Route = createFileRoute("/api/public/download-codebase")({
  server: {
    handlers: {
      GET: async () => {
        return new Promise<Response>((resolve) => {
          const zip = spawn("zip", [
            "-r",
            "-",
            ".",
            "-x",
            "node_modules/*",
            "-x",
            ".git/*",
            "-x",
            "dist/*",
            "-x",
            ".tanstack/*",
            "-x",
            "*.log",
            "-x",
            ".env",
            "-x",
            ".env.*",
          ], {
            cwd: "/dev-server",
          });

          const chunks: Buffer[] = [];
          zip.stdout.on("data", (chunk: Buffer) => chunks.push(chunk));
          zip.stderr.on("data", () => {});

          zip.on("close", (code) => {
            if (code !== 0) {
              resolve(
                new Response("Failed to generate ZIP", { status: 500 })
              );
              return;
            }
            const buffer = Buffer.concat(chunks);
            resolve(
              new Response(buffer, {
                status: 200,
                headers: {
                  "Content-Type": "application/zip",
                  "Content-Disposition": 'attachment; filename="ayurvedic-plus-codebase.zip"',
                  "Content-Length": String(buffer.length),
                },
              })
            );
          });

          zip.on("error", () => {
            resolve(
              new Response("ZIP generation not available in this environment", { status: 500 })
            );
          });
        });
      },
    },
  },
});
