import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, Clock, ArrowRight } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { treatments } from "@/lib/mock-data";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import herbs from "@/assets/treatment-herbs.jpg";
import oil from "@/assets/treatment-oil.jpg";
import leaves from "@/assets/treatment-leaves.jpg";

export const Route = createFileRoute("/treatments")({
  head: () => ({
    meta: [
      { title: "Treatments — Ayurvedic Plus Clinic" },
      { name: "description", content: "Panchakarma, weight management, hair & skin care, stress relief, and lifestyle consultations." },
    ],
  }),
  component: TreatmentsPage,
});

const images = [herbs, oil, leaves, herbs, oil, leaves];

function TreatmentsPage() {
  return (
    <AppShell>
      <section className="border-b border-border/60 bg-secondary/30">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">Treatments</p>
          <h1 className="mt-2 font-display text-4xl font-semibold sm:text-5xl">Programs rooted in tradition</h1>
          <p className="mt-3 max-w-2xl text-muted-foreground">Every protocol begins with a 60-minute consultation to map your prakriti, vikriti, and lifestyle.</p>
        </div>
      </section>

      <section className="py-16">
        <div className="mx-auto grid max-w-7xl gap-6 px-4 sm:px-6 lg:grid-cols-2">
          {treatments.map((t, i) => (
            <article key={t.id} className="surface-card hover-lift overflow-hidden">
              <div className="grid grid-cols-[1fr_1fr] gap-0">
                <img src={images[i]} alt={t.name} width={400} height={300} loading="lazy" className="h-48 w-full object-cover sm:h-full" />
                <div className="p-6">
                  <Badge className="rounded-full bg-primary/10 text-primary hover:bg-primary/15">{t.tagline}</Badge>
                  <h2 className="mt-3 font-display text-2xl font-semibold">{t.name}</h2>
                  <p className="mt-2 text-sm text-muted-foreground line-clamp-3">{t.description}</p>
                  <div className="mt-4 flex items-center gap-4 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" /> {t.duration}</span>
                    <span className="font-semibold text-foreground">from ${t.price}</span>
                  </div>
                  <ul className="mt-4 space-y-1.5">
                    {t.benefits.map((b) => (
                      <li key={b} className="flex items-center gap-2 text-sm">
                        <Check className="h-3.5 w-3.5 text-primary" /> {b}
                      </li>
                    ))}
                  </ul>
                  <Button asChild size="sm" className="mt-5 rounded-full">
                    <Link to="/booking">Book this <ArrowRight className="ml-1 h-3.5 w-3.5" /></Link>
                  </Button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>
    </AppShell>
  );
}
