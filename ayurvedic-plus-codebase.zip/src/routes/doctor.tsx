import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell } from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { appointments, patients, doctors } from "@/lib/mock-data";
import { Search, Stethoscope, NotebookPen, Pill, Plus, Trash2, CalendarDays } from "lucide-react";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";

export const Route = createFileRoute("/doctor")({
  head: () => ({ meta: [{ title: "Doctor Dashboard — Ayurvedic Plus Clinic" }] }),
  component: DoctorDashboard,
});

const me = doctors[0];

function DoctorDashboard() {
  const [q, setQ] = useState("");
  const [meds, setMeds] = useState([{ name: "", dosage: "", duration: "" }]);
  const [notes, setNotes] = useState("");

  const filtered = patients.filter((p) => p.name.toLowerCase().includes(q.toLowerCase()));
  const today = appointments.slice(0, 5);

  return (
    <AppShell>
      <section className="border-b border-border/60 bg-secondary/30">
        <div className="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-4 py-8 sm:px-6">
          <div className="flex min-w-0 items-center gap-4">
            <div className="grid h-14 w-14 shrink-0 place-items-center rounded-full bg-primary/10 font-display text-lg font-semibold text-primary">{me.avatar}</div>
            <div className="min-w-0">
              <p className="text-xs uppercase tracking-wider text-muted-foreground">Doctor dashboard</p>
              <h1 className="truncate font-display text-2xl font-semibold sm:text-3xl">{me.name}</h1>
              <p className="text-sm text-muted-foreground">{me.specialty}</p>
            </div>
          </div>
          <Badge className="shrink-0 rounded-full bg-primary/10 text-primary hover:bg-primary/15">On duty</Badge>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <div className="mb-6 grid gap-4 sm:grid-cols-4">
          {[
            { l: "Today", v: "8", s: "appointments" },
            { l: "This week", v: "42", s: "consultations" },
            { l: "Active patients", v: "126", s: "in care" },
            { l: "Avg rating", v: "4.9", s: "from 312 reviews" },
          ].map((s) => (
            <Card key={s.l}><CardContent className="p-5">
              <p className="text-xs uppercase tracking-wider text-muted-foreground">{s.l}</p>
              <p className="mt-2 font-display text-2xl font-semibold text-primary">{s.v}</p>
              <p className="text-xs text-muted-foreground">{s.s}</p>
            </CardContent></Card>
          ))}
        </div>

        <Tabs defaultValue="schedule">
          <TabsList>
            <TabsTrigger value="schedule"><CalendarDays className="mr-1 h-3.5 w-3.5" />Schedule</TabsTrigger>
            <TabsTrigger value="patients"><Stethoscope className="mr-1 h-3.5 w-3.5" />Patients</TabsTrigger>
            <TabsTrigger value="notes"><NotebookPen className="mr-1 h-3.5 w-3.5" />Consultation notes</TabsTrigger>
            <TabsTrigger value="rx"><Pill className="mr-1 h-3.5 w-3.5" />Prescription</TabsTrigger>
          </TabsList>

          <TabsContent value="schedule" className="mt-6">
            <Card><CardContent className="p-0">
              <div className="divide-y divide-border">
                {today.map((a) => (
                  <div key={a.id} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 p-5 sm:grid-cols-[120px_1fr_auto]">
                    <div className="hidden sm:block">
                      <p className="font-display text-xl font-semibold">{a.time}</p>
                      <p className="text-xs text-muted-foreground">{format(parseISO(a.date), "dd MMM")}</p>
                    </div>
                    <div className="min-w-0">
                      <p className="truncate font-semibold">{a.patient}</p>
                      <p className="truncate text-sm text-muted-foreground">{a.treatment} · {a.mode}</p>
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      <Badge variant="outline" className="rounded-full capitalize">{a.status}</Badge>
                      <Button size="sm" variant="outline" className="rounded-full">Open</Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent></Card>
          </TabsContent>

          <TabsContent value="patients" className="mt-6 space-y-4">
            <div className="relative max-w-md">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search patients…" className="pl-9" />
            </div>
            <Card><CardContent className="p-0">
              <div className="divide-y divide-border">
                {filtered.map((p) => (
                  <div key={p.id} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 p-5 sm:grid-cols-[1fr_auto_auto_auto]">
                    <div className="flex min-w-0 items-center gap-3">
                      <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-primary/10 text-sm font-semibold text-primary">{p.name.split(" ").map((s) => s[0]).join("")}</div>
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold">{p.name}</p>
                        <p className="truncate text-xs text-muted-foreground">{p.age} · {p.gender} · {p.prakriti}</p>
                      </div>
                    </div>
                    <div className="hidden flex-wrap gap-1 sm:flex">
                      {p.conditions.map((c) => <Badge key={c} variant="secondary" className="rounded-full">{c}</Badge>)}
                    </div>
                    <p className="hidden text-xs text-muted-foreground sm:block">Last visit {format(parseISO(p.lastVisit), "dd MMM")}</p>
                    <Button size="sm" variant="ghost">View</Button>
                  </div>
                ))}
              </div>
            </CardContent></Card>
          </TabsContent>

          <TabsContent value="notes" className="mt-6">
            <Card><CardContent className="p-6 space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="grid gap-2"><Label>Patient</Label><Input defaultValue="Arjun Mehta" /></div>
                <div className="grid gap-2"><Label>Date</Label><Input type="date" defaultValue="2026-06-17" /></div>
              </div>
              <div className="grid gap-2"><Label>Chief complaints</Label><Textarea rows={3} placeholder="Disturbed sleep, occasional acidity, mild anxiety…" /></div>
              <div className="grid gap-2"><Label>Examination</Label><Textarea rows={3} placeholder="Pulse: Vata-Pitta. BP 124/82. Tongue: coated centrally…" /></div>
              <div className="grid gap-2"><Label>Plan</Label><Textarea rows={3} placeholder="Shirodhara 7 sittings, Brahmi Ghrita at bedtime, dietary adjustments…" /></div>
              <Button className="rounded-full" onClick={() => toast.success("Notes saved")}>Save notes</Button>
            </CardContent></Card>
          </TabsContent>

          <TabsContent value="rx" className="mt-6">
            <Card><CardContent className="p-6 space-y-4">
              <h3 className="font-display text-lg font-semibold">New prescription</h3>
              {meds.map((m, i) => (
                <div key={i} className="grid gap-3 sm:grid-cols-[2fr_1.2fr_1fr_auto]">
                  <Input placeholder="Medicine (e.g. Ashwagandha)" value={m.name} onChange={(e) => { const c = [...meds]; c[i].name = e.target.value; setMeds(c); }} />
                  <Input placeholder="Dosage" value={m.dosage} onChange={(e) => { const c = [...meds]; c[i].dosage = e.target.value; setMeds(c); }} />
                  <Input placeholder="Duration" value={m.duration} onChange={(e) => { const c = [...meds]; c[i].duration = e.target.value; setMeds(c); }} />
                  <Button variant="ghost" size="icon" onClick={() => setMeds(meds.filter((_, x) => x !== i))}><Trash2 className="h-4 w-4" /></Button>
                </div>
              ))}
              <Button variant="outline" size="sm" className="rounded-full" onClick={() => setMeds([...meds, { name: "", dosage: "", duration: "" }])}><Plus className="mr-1 h-3.5 w-3.5" />Add medicine</Button>
              <div className="grid gap-2"><Label>Notes</Label><Textarea rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Avoid caffeine, light dinner before 7:30pm…" /></div>
              <Button className="rounded-full" onClick={() => toast.success("Prescription sent to patient")}>Send prescription</Button>
            </CardContent></Card>
          </TabsContent>
        </Tabs>
      </section>
    </AppShell>
  );
}
