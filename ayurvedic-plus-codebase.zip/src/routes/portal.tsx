import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { appointments, prescriptions, reports, progressData } from "@/lib/mock-data";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid } from "recharts";
import { FileText, Pill, CalendarDays, User, Upload, Download } from "lucide-react";
import { format, parseISO } from "date-fns";

export const Route = createFileRoute("/portal")({
  head: () => ({ meta: [{ title: "Patient Portal — Ayurvedic Plus Clinic" }] }),
  component: PortalPage,
});

const me = {
  name: "Arjun Mehta",
  email: "arjun@example.com",
  phone: "+91 98201 12345",
  prakriti: "Vata-Pitta",
  age: 38,
  joined: "2024-03-12",
};

function PortalPage() {
  const mine = appointments.filter((a) => a.patient === me.name);

  return (
    <AppShell>
      <section className="border-b border-border/60 bg-secondary/30">
        <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-8 sm:px-6">
          <div className="grid h-14 w-14 place-items-center rounded-full gradient-emerald text-primary-foreground font-display text-lg shrink-0">AM</div>
          <div className="min-w-0">
            <p className="text-xs uppercase tracking-wider text-muted-foreground">Patient portal</p>
            <h1 className="truncate font-display text-2xl font-semibold sm:text-3xl">Welcome, {me.name}</h1>
            <p className="text-sm text-muted-foreground">Prakriti · {me.prakriti}</p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <div className="mb-8 grid gap-4 sm:grid-cols-3">
          {[
            { label: "Active treatments", value: "2", sub: "Stress · Lifestyle" },
            { label: "Next appointment", value: "Jun 22", sub: "12:00 · Dr. Sharma" },
            { label: "Wellness score", value: "74", sub: "+12 this month" },
          ].map((s) => (
            <Card key={s.label}>
              <CardContent className="p-5">
                <p className="text-xs uppercase tracking-wider text-muted-foreground">{s.label}</p>
                <p className="mt-2 font-display text-2xl font-semibold text-primary">{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.sub}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <Tabs defaultValue="appointments">
          <TabsList className="flex h-auto flex-wrap gap-1 bg-muted/60 p-1">
            <TabsTrigger value="appointments"><CalendarDays className="mr-1 h-3.5 w-3.5" />Appointments</TabsTrigger>
            <TabsTrigger value="history"><FileText className="mr-1 h-3.5 w-3.5" />Medical History</TabsTrigger>
            <TabsTrigger value="prescriptions"><Pill className="mr-1 h-3.5 w-3.5" />Prescriptions</TabsTrigger>
            <TabsTrigger value="reports"><Upload className="mr-1 h-3.5 w-3.5" />Reports</TabsTrigger>
            <TabsTrigger value="profile"><User className="mr-1 h-3.5 w-3.5" />Profile</TabsTrigger>
          </TabsList>

          <TabsContent value="appointments" className="mt-6">
            <Card>
              <CardContent className="p-0">
                <div className="divide-y divide-border">
                  {mine.map((a) => (
                    <div key={a.id} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 p-5 sm:grid-cols-[80px_1fr_auto]">
                      <div className="hidden text-center sm:block">
                        <p className="font-display text-2xl font-semibold text-primary">{format(parseISO(a.date), "dd")}</p>
                        <p className="text-xs uppercase tracking-wider text-muted-foreground">{format(parseISO(a.date), "MMM")}</p>
                      </div>
                      <div className="min-w-0">
                        <p className="truncate font-semibold">{a.treatment}</p>
                        <p className="truncate text-sm text-muted-foreground">{a.time} · {a.mode}</p>
                      </div>
                      <Badge
                        className="shrink-0 rounded-full"
                        variant={a.status === "confirmed" ? "default" : a.status === "completed" ? "secondary" : "outline"}
                      >
                        {a.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history" className="mt-6 grid gap-4 lg:grid-cols-[1.2fr_1fr]">
            <Card>
              <CardContent className="p-6">
                <h3 className="font-display text-lg font-semibold">Wellness progress</h3>
                <p className="text-sm text-muted-foreground">6-week trend across sleep, energy, and digestion.</p>
                <div className="mt-4 h-60">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={progressData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                      <XAxis dataKey="week" stroke="var(--muted-foreground)" fontSize={12} />
                      <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                      <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12 }} />
                      <Line type="monotone" dataKey="score" stroke="var(--primary)" strokeWidth={2.5} dot={{ r: 4 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <h3 className="font-display text-lg font-semibold">Conditions</h3>
                <div className="mt-3 flex flex-wrap gap-2">
                  {["Insomnia", "Acidity", "Mild anxiety"].map((c) => (
                    <Badge key={c} variant="secondary" className="rounded-full">{c}</Badge>
                  ))}
                </div>
                <h4 className="mt-6 text-sm font-semibold">Allergies</h4>
                <p className="text-sm text-muted-foreground">None reported</p>
                <h4 className="mt-6 text-sm font-semibold">Lifestyle</h4>
                <ul className="mt-2 space-y-2 text-sm">
                  <li className="flex justify-between"><span className="text-muted-foreground">Sleep</span><span>6.5 hrs avg</span></li>
                  <li className="flex justify-between"><span className="text-muted-foreground">Exercise</span><span>3x / week</span></li>
                  <li className="flex justify-between"><span className="text-muted-foreground">Stress level</span><span>Moderate</span></li>
                </ul>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="prescriptions" className="mt-6 grid gap-4 md:grid-cols-2">
            {prescriptions.map((rx) => (
              <Card key={rx.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-xs uppercase tracking-wider text-muted-foreground">Prescription</p>
                      <h3 className="mt-1 font-display text-lg font-semibold">{rx.doctor}</h3>
                      <p className="text-sm text-muted-foreground">{format(parseISO(rx.date), "dd MMM yyyy")}</p>
                    </div>
                    <Button size="sm" variant="ghost"><Download className="h-4 w-4" /></Button>
                  </div>
                  <div className="mt-4 space-y-3">
                    {rx.medicines.map((m) => (
                      <div key={m.name} className="rounded-lg border border-border/60 p-3">
                        <p className="text-sm font-semibold">{m.name}</p>
                        <p className="text-xs text-muted-foreground">{m.dosage} · {m.duration}</p>
                      </div>
                    ))}
                  </div>
                  <p className="mt-4 text-sm text-muted-foreground italic">"{rx.notes}"</p>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="reports" className="mt-6">
            <Card>
              <CardContent className="p-6">
                <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 sm:flex sm:items-center sm:justify-between">
                  <div className="min-w-0">
                    <h3 className="font-display text-lg font-semibold">Your reports</h3>
                    <p className="text-sm text-muted-foreground">Upload lab tests for your doctor to review.</p>
                  </div>
                  <Button className="shrink-0 rounded-full"><Upload className="mr-1 h-4 w-4" /> Upload</Button>
                </div>
                <div className="mt-5 divide-y divide-border">
                  {reports.map((r) => (
                    <div key={r.id} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 py-3">
                      <div className="flex min-w-0 items-center gap-3">
                        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary"><FileText className="h-4 w-4" /></span>
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium">{r.name}</p>
                          <p className="text-xs text-muted-foreground">{r.type} · {r.size} · {format(parseISO(r.date), "dd MMM yyyy")}</p>
                        </div>
                      </div>
                      <Button size="sm" variant="ghost"><Download className="h-4 w-4" /></Button>
                    </div>
                  ))}
                </div>
                <div className="mt-6">
                  <p className="text-sm font-semibold">Treatment progress</p>
                  <Progress value={68} className="mt-2" />
                  <p className="mt-1 text-xs text-muted-foreground">68% of your 6-week stress program completed.</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="profile" className="mt-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="font-display text-lg font-semibold">Profile details</h3>
                <div className="mt-5 grid gap-4 sm:grid-cols-2">
                  <div className="grid gap-2"><Label>Full name</Label><Input defaultValue={me.name} /></div>
                  <div className="grid gap-2"><Label>Email</Label><Input defaultValue={me.email} /></div>
                  <div className="grid gap-2"><Label>Phone</Label><Input defaultValue={me.phone} /></div>
                  <div className="grid gap-2"><Label>Prakriti</Label><Input defaultValue={me.prakriti} /></div>
                </div>
                <Button className="mt-6 rounded-full">Save changes</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </section>
    </AppShell>
  );
}
