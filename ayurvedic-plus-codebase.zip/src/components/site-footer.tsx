import { Leaf, MessageCircle, Mail, Phone } from "lucide-react";
import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="border-t border-border/60 bg-secondary/40">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl gradient-emerald text-primary-foreground">
              <Leaf className="h-4 w-4" />
            </span>
            <span className="font-display text-lg font-semibold">Ayurvedic Plus Clinic</span>
          </div>
          <p className="mt-3 max-w-sm text-sm text-muted-foreground">
            Personalized Ayurvedic care, modern facilities, and outcomes you can measure. Rooted in tradition, designed for today.
          </p>
        </div>
        <div>
          <h4 className="text-sm font-semibold">Explore</h4>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li><Link to="/treatments" className="hover:text-foreground">Treatments</Link></li>
            <li><Link to="/booking" className="hover:text-foreground">Book Appointment</Link></li>
            <li><Link to="/portal" className="hover:text-foreground">Patient Portal</Link></li>
            <li><Link to="/consult" className="hover:text-foreground">Online Consultation</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold">Contact</h4>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li className="flex items-center gap-2"><Phone className="h-3.5 w-3.5" /> +91 98200 00000</li>
            <li className="flex items-center gap-2"><Mail className="h-3.5 w-3.5" /> care@ayurvedicplus.in</li>
            <li className="flex items-center gap-2"><MessageCircle className="h-3.5 w-3.5" /> WhatsApp support</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border/60">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-5 text-xs text-muted-foreground sm:flex-row sm:px-6">
          <p>© {new Date().getFullYear()} Ayurvedic Plus Clinic. All rights reserved.</p>
          <p>Holistic care · Modern science</p>
        </div>
      </div>
    </footer>
  );
}
