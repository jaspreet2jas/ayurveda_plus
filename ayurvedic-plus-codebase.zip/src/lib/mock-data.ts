export type Doctor = {
  id: string;
  name: string;
  specialty: string;
  experience: number;
  rating: number;
  avatar: string;
  bio: string;
};

export type Treatment = {
  id: string;
  name: string;
  tagline: string;
  description: string;
  duration: string;
  price: number;
  benefits: string[];
};

export type Appointment = {
  id: string;
  patient: string;
  doctorId: string;
  treatment: string;
  date: string; // ISO
  time: string;
  status: "confirmed" | "pending" | "completed" | "cancelled";
  mode: "in-clinic" | "online";
};

export type Patient = {
  id: string;
  name: string;
  age: number;
  gender: "Male" | "Female";
  phone: string;
  email: string;
  prakriti: "Vata" | "Pitta" | "Kapha" | "Vata-Pitta" | "Pitta-Kapha";
  joined: string;
  lastVisit: string;
  conditions: string[];
};

export type Prescription = {
  id: string;
  date: string;
  doctor: string;
  medicines: { name: string; dosage: string; duration: string }[];
  notes: string;
};

export type Report = {
  id: string;
  name: string;
  date: string;
  type: string;
  size: string;
};

export const doctors: Doctor[] = [
  { id: "d1", name: "Dr. Ananya Sharma", specialty: "Panchakarma & Detox", experience: 14, rating: 4.9, avatar: "AS", bio: "Specialist in classical Panchakarma with a gentle, modern approach to chronic care." },
  { id: "d2", name: "Dr. Rohan Iyer", specialty: "Lifestyle & Stress", experience: 11, rating: 4.8, avatar: "RI", bio: "Blends Ayurveda with mindfulness for executive burnout and sleep restoration." },
  { id: "d3", name: "Dr. Meera Joshi", specialty: "Skin & Hair Care", experience: 9, rating: 4.9, avatar: "MJ", bio: "Treats dermatology and trichology concerns with herbal formulations." },
  { id: "d4", name: "Dr. Vikram Nair", specialty: "Weight Management", experience: 12, rating: 4.7, avatar: "VN", bio: "Designs metabolic reset programs rooted in dosha-specific nutrition." },
];

export const treatments: Treatment[] = [
  { id: "t1", name: "Panchakarma", tagline: "Five-step deep detox", description: "A classical 7–21 day cleansing program to reset metabolism, immunity, and mental clarity.", duration: "7–21 days", price: 1499, benefits: ["Deep detoxification", "Improved digestion", "Mental clarity"] },
  { id: "t2", name: "Weight Management", tagline: "Metabolic reset", description: "Personalized diet, herbal support, and Udvartana therapy for sustainable weight balance.", duration: "6–12 weeks", price: 899, benefits: ["Sustainable loss", "Hormonal balance", "Energy lift"] },
  { id: "t3", name: "Hair Care", tagline: "Roots to length", description: "Shiro Abhyanga and herbal masks for hair fall, dandruff, and premature greying.", duration: "4 weeks", price: 349, benefits: ["Reduced hair fall", "Scalp nourishment", "Stronger roots"] },
  { id: "t4", name: "Skin Care", tagline: "Inside-out radiance", description: "Mukha Lepa and internal herbs for acne, pigmentation, and chronic skin conditions.", duration: "4–8 weeks", price: 449, benefits: ["Clear complexion", "Even tone", "Anti-aging"] },
  { id: "t5", name: "Stress Management", tagline: "Calm the nervous system", description: "Shirodhara, breathwork, and adaptogens to relieve anxiety, insomnia, and burnout.", duration: "3–6 weeks", price: 599, benefits: ["Better sleep", "Lower cortisol", "Steady mood"] },
  { id: "t6", name: "Lifestyle Consultation", tagline: "Your daily ritual", description: "1:1 consultation to design a Dinacharya routine matched to your Prakriti and goals.", duration: "60 minutes", price: 129, benefits: ["Personal protocol", "Diet plan", "Daily routine"] },
];

export const patients: Patient[] = [
  { id: "p1", name: "Arjun Mehta", age: 38, gender: "Male", phone: "+91 98201 12345", email: "arjun@example.com", prakriti: "Vata-Pitta", joined: "2024-03-12", lastVisit: "2026-06-10", conditions: ["Insomnia", "Acidity"] },
  { id: "p2", name: "Priya Kapoor", age: 31, gender: "Female", phone: "+91 99877 21221", email: "priya@example.com", prakriti: "Pitta", joined: "2024-08-04", lastVisit: "2026-06-14", conditions: ["Migraine", "PCOS"] },
  { id: "p3", name: "Sanjay Rao", age: 52, gender: "Male", phone: "+91 90123 88112", email: "sanjay@example.com", prakriti: "Kapha", joined: "2023-11-22", lastVisit: "2026-05-30", conditions: ["Type 2 Diabetes", "Knee pain"] },
  { id: "p4", name: "Neha Verma", age: 27, gender: "Female", phone: "+91 98213 55667", email: "neha@example.com", prakriti: "Vata", joined: "2025-01-09", lastVisit: "2026-06-15", conditions: ["Hair fall", "Anxiety"] },
  { id: "p5", name: "Karan Singh", age: 44, gender: "Male", phone: "+91 91100 44210", email: "karan@example.com", prakriti: "Pitta-Kapha", joined: "2024-12-01", lastVisit: "2026-06-12", conditions: ["Hypertension"] },
  { id: "p6", name: "Riya Bhat", age: 34, gender: "Female", phone: "+91 99008 12009", email: "riya@example.com", prakriti: "Vata-Pitta", joined: "2025-04-17", lastVisit: "2026-06-08", conditions: ["Eczema"] },
];

export const appointments: Appointment[] = [
  { id: "a1", patient: "Arjun Mehta", doctorId: "d2", treatment: "Stress Management", date: "2026-06-18", time: "10:00", status: "confirmed", mode: "in-clinic" },
  { id: "a2", patient: "Priya Kapoor", doctorId: "d3", treatment: "Skin Care", date: "2026-06-18", time: "11:30", status: "confirmed", mode: "online" },
  { id: "a3", patient: "Sanjay Rao", doctorId: "d1", treatment: "Panchakarma", date: "2026-06-19", time: "09:00", status: "pending", mode: "in-clinic" },
  { id: "a4", patient: "Neha Verma", doctorId: "d3", treatment: "Hair Care", date: "2026-06-19", time: "14:00", status: "confirmed", mode: "in-clinic" },
  { id: "a5", patient: "Karan Singh", doctorId: "d4", treatment: "Weight Management", date: "2026-06-20", time: "16:00", status: "confirmed", mode: "online" },
  { id: "a6", patient: "Riya Bhat", doctorId: "d3", treatment: "Skin Care", date: "2026-06-21", time: "10:30", status: "completed", mode: "in-clinic" },
  { id: "a7", patient: "Arjun Mehta", doctorId: "d1", treatment: "Lifestyle Consultation", date: "2026-06-22", time: "12:00", status: "pending", mode: "online" },
];

export const prescriptions: Prescription[] = [
  {
    id: "rx1", date: "2026-06-10", doctor: "Dr. Rohan Iyer",
    medicines: [
      { name: "Brahmi Ghrita", dosage: "1 tsp at bedtime", duration: "30 days" },
      { name: "Ashwagandha Churna", dosage: "3g twice daily", duration: "45 days" },
    ],
    notes: "Continue Pranayama 15 minutes morning. Avoid caffeine post 4pm.",
  },
  {
    id: "rx2", date: "2026-05-02", doctor: "Dr. Ananya Sharma",
    medicines: [
      { name: "Triphala Churna", dosage: "5g warm water before bed", duration: "60 days" },
    ],
    notes: "Light dinner before 7:30pm. Walk 30 minutes daily.",
  },
];

export const reports: Report[] = [
  { id: "r1", name: "Complete Blood Count.pdf", date: "2026-05-28", type: "Lab", size: "320 KB" },
  { id: "r2", name: "Lipid Profile.pdf", date: "2026-04-15", type: "Lab", size: "284 KB" },
  { id: "r3", name: "Liver Function.pdf", date: "2026-03-22", type: "Lab", size: "298 KB" },
  { id: "r4", name: "Treatment Progress Q2.pdf", date: "2026-06-01", type: "Progress", size: "512 KB" },
];

export const revenueData = [
  { month: "Jan", revenue: 18400, patients: 142 },
  { month: "Feb", revenue: 21200, patients: 168 },
  { month: "Mar", revenue: 24800, patients: 189 },
  { month: "Apr", revenue: 22100, patients: 174 },
  { month: "May", revenue: 27600, patients: 211 },
  { month: "Jun", revenue: 31900, patients: 238 },
];

export const treatmentDistribution = [
  { name: "Panchakarma", value: 32 },
  { name: "Stress", value: 24 },
  { name: "Skin & Hair", value: 18 },
  { name: "Weight", value: 14 },
  { name: "Lifestyle", value: 12 },
];

export const progressData = [
  { week: "W1", score: 42 },
  { week: "W2", score: 48 },
  { week: "W3", score: 55 },
  { week: "W4", score: 61 },
  { week: "W5", score: 68 },
  { week: "W6", score: 74 },
];
